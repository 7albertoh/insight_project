from setuptools import setup, find_packages

setup(name="project_name",
      version="1.0",
      py_modules=["project_name"],
     )


