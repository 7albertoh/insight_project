from setuptools import setup, find_packages

setup(name="projec_tname",
      version="0.1",
      py_modules=["project_name"],
     )


